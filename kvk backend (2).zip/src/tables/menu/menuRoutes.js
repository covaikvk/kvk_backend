// routes/menuRoutes.js
const express = require("express");
const router = express.Router();
const menuController = require("./menuController");

// CRUD Routes
router.get("/", menuController.getMenus);          // Get all menus
router.get("/:id", menuController.getMenuById);   // Get menu by ID
router.post("/", menuController.createMenu);      // Create new menu
router.put("/:id", menuController.updateMenu);   // Update menu
router.delete("/:id", menuController.deleteMenu);// Delete menu

module.exports = router;
