// controllers/menuController.js
const connectDB = require("../../../src/config/db");

// Get all menu items
exports.getMenus = async (req, res) => {
  try {
    const connection = await connectDB();
    const [rows] = await connection.query("SELECT * FROM menuname");
    res.status(200).json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};

// Get single menu item by ID
exports.getMenuById = async (req, res) => {
  try {
    const { id } = req.params;
    const connection = await connectDB();
    const [rows] = await connection.query("SELECT * FROM menuname WHERE id = ?", [id]);

    if (rows.length === 0) return res.status(404).json({ message: "Menu not found" });

    res.status(200).json(rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};

// Create a new menu item
exports.createMenu = async (req, res) => {
  try {
    const { name, image_url, banner_url } = req.body;

    if (!name) return res.status(400).json({ message: "Name is required" });

    const connection = await connectDB();
    const [result] = await connection.query(
      "INSERT INTO menuname (name, image_url, banner_url) VALUES (?, ?, ?)",
      [name, image_url || null, banner_url || null]
    );

    res.status(201).json({ id: result.insertId, name, image_url, banner_url });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};

// Update a menu item
exports.updateMenu = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, image_url, banner_url } = req.body;

    const connection = await connectDB();
    const [result] = await connection.query(
      "UPDATE menuname SET name = ?, image_url = ?, banner_url = ? WHERE id = ?",
      [name, image_url, banner_url, id]
    );

    if (result.affectedRows === 0) return res.status(404).json({ message: "Menu not found" });

    res.status(200).json({ message: "Menu updated successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};

// Delete a menu item
exports.deleteMenu = async (req, res) => {
  try {
    const { id } = req.params;
    const connection = await connectDB();
    const [result] = await connection.query("DELETE FROM menuname WHERE id = ?", [id]);

    if (result.affectedRows === 0) return res.status(404).json({ message: "Menu not found" });

    res.status(200).json({ message: "Menu deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server Error" });
  }
};
